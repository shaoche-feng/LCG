from dataclasses import dataclass, field
import time
from typing import Dict, Optional, Tuple

import torch
from torch import Tensor

from data import Dataset
from models.diffusion.denoiser import Denoiser, SigmaDistributionConfig

from .forward_jvp import assert_setup_valid, frozen_named_parameters, make_jvp_bank
from .intrinsic_reward import make_lcg_intrinsic_reward_fn
from .precision import historical_precision
from .reward_normalization import RunningRMS, RunningRMSConfig
from .theta_s import ThetaSConfig, selected_named_parameters


@dataclass
class LCGConfig:
    enabled: bool = False
    h_d_batch_size: int = 40
    precision_num_mc: int = 3  # historical precision: IID sigma draws per historical transition (backward VJP)
    damping: float = 1e-4
    beta: float = 1.0
    candidate_num_mc: int = 24  # candidate scoring: IID sigma draws per candidate (forward JVP, Full CRN)
    candidate_chunk_size: int = 16
    rms_enabled: bool = True
    rms_alpha: float = 1.0
    rms_ema_decay: float = 0.99
    rms_eps: float = 1e-8
    theta_s: ThetaSConfig = field(kw_only=True)  # which parameters belong to theta_S -- see config/intrinsic_reward/lcg.yaml


class LCGLifecycle:
    """Owns the outer-round LCG state.

    theta_S selection happens ONCE per lifecycle/model instance (cached on the first
    refresh()): cfg.theta_s is fixed for the run, the denoiser architecture is fixed, and
    optimizer steps mutate the same nn.Parameter objects in place, so theta_S's
    membership/order/object-identity cannot change between rounds -- reselecting it every
    round would be pure waste and would risk two rounds silently disagreeing on which
    coordinate h_D[k]/eta[k] refers to if selection were ever nondeterministic.

    Everything else still refreshes once per completed world-model update round:

        (theta_S resolved once, cached) -> h_D refresh (backward VJP, simple MC) ->
        candidate JVP-bank refresh (forward JVP, simple MC, Full CRN) -> RunningRMS reset
        -> LCG ActorCritic inner training (fixed theta_S/h_D/bank; RMS evolves normally
           across the round's ActorCritic optimizer steps)
        -> next world-model round -> h_D/bank/RMS refresh again (theta_S reused)

    h_D is estimated via lcg.precision.historical_precision, which samples historical
    transitions uniformly without replacement (lcg.precision.
    sample_uniform_historical_transitions) and applies the N/B correction using
    N=dataset.num_steps by default -- both passed explicitly here for clarity. theta_S
    and the RunningRMS formula are fixed by the method, not configurable here.

    Candidate scoring is always forward-mode JVP + simple Monte Carlo + Full CRN -- there
    is no alternative estimator to select.

    `round_id` identifies the current outer round (0-indexed, set at the start of
    refresh() and held constant until the next refresh()) -- used both for deterministic
    per-round local seeding and by external callers (see trainer.py's [LCG-TIMING] logs)
    as the round label. `refresh()` and the returned intrinsic_reward_fn print `[LCG]`-
    prefixed diagnostic lines (round id, content fingerprints of h_D/bank, RMS state,
    timing) so an external harness can verify within-round persistence from process
    stdout alone.
    """

    def __init__(self, cfg: LCGConfig, sigma_cfg: SigmaDistributionConfig, img_channels: int, img_size: int, device: torch.device):
        self.cfg = cfg
        self.sigma_cfg = sigma_cfg
        self.img_channels = img_channels
        self.img_size = img_size
        self.device = device

        self.round_id = -1

        # theta_S is resolved once per lifecycle/model instance and cached here (see
        # refresh()); _theta_s_named continues to point at the SAME live nn.Parameter
        # objects denoiser.inner_model owns, so later optimizer steps are visible through
        # it automatically -- it is never cloned/detached/snapshotted.
        self._theta_s_named: Optional[Dict[str, torch.nn.Parameter]] = None
        self._theta_s_names: Optional[Tuple[str, ...]] = None
        self._theta_s_dim: Optional[int] = None
        self._denoiser_ref: Optional[Denoiser] = None

        self.h_D: Optional[Tensor] = None
        self.bank = None
        self.rms: Optional[RunningRMS] = None
        self.intrinsic_reward_fn = None

    def refresh(self, denoiser: Denoiser, dataset: Dataset) -> None:
        assert self.cfg.enabled
        self.round_id += 1

        if self._theta_s_named is None:
            # First refresh for this lifecycle instance: resolve theta_S once and cache
            # it. Every later refresh() reuses this exact mapping -- selected_named_
            # parameters() is never called again for the life of this object.
            theta_s_named = selected_named_parameters(denoiser, self.cfg.theta_s)
            self._theta_s_named = theta_s_named
            self._theta_s_names = tuple(theta_s_named.keys())
            self._theta_s_dim = sum(p.numel() for p in theta_s_named.values())
            self._denoiser_ref = denoiser
            print(
                f"[LCG] theta_S: parameter tensors={len(theta_s_named)} "
                f"scalar parameters={self._theta_s_dim} "
                f"include={list(self.cfg.theta_s.include)} exclude={list(self.cfg.theta_s.exclude)}",
                flush=True,
            )
        elif denoiser is not self._denoiser_ref:
            raise RuntimeError(
                "LCGLifecycle.refresh() was called with a different denoiser instance "
                "than the one theta_S was cached against on this lifecycle's first "
                "refresh() (round 0). theta_S selection (membership/order/parameter "
                "object identity) is resolved once per LCGLifecycle instance and reused "
                "on every later round, so h_D[k]/eta[k] stay pinned to the same "
                "coordinate k for the object's whole life -- silently reselecting against "
                "a new denoiser could change that mapping without any of the round-to-"
                "round machinery noticing. If the trainer genuinely needs to replace the "
                "denoiser mid-run, construct a new LCGLifecycle for it instead."
            )

        theta_s_named = self._theta_s_named
        params = list(theta_s_named.values())
        seed = self.round_id

        t0 = time.time()
        self.h_D = historical_precision(
            denoiser, params, dataset, self.sigma_cfg,
            B=self.cfg.h_d_batch_size, N=dataset.num_steps, num_mc=self.cfg.precision_num_mc,
            beta=self.cfg.beta, damping=self.cfg.damping, seed=seed,
        )
        assert self.h_D.numel() == self._theta_s_dim, (
            f"h_D dim {self.h_D.numel()} != cached theta_S dim {self._theta_s_dim} -- "
            "theta_s config must have changed incompatibly with the cached selection."
        )
        t_h_d = time.time() - t0

        y_shape = torch.Size([1, self.img_channels, self.img_size, self.img_size])
        t0 = time.time()
        frozen_named = frozen_named_parameters(denoiser, theta_s_named)
        assert_setup_valid(theta_s_named, self.h_D, d_S=self._theta_s_dim)
        self.bank = make_jvp_bank(
            self.sigma_cfg, y_shape, self._theta_s_dim, self.device,
            num_samples=self.cfg.candidate_num_mc, seed=seed + 1_000_000,
        )
        base_hook = make_lcg_intrinsic_reward_fn(
            denoiser, theta_s_named, frozen_named, self.h_D, self.bank, chunk_size=self.cfg.candidate_chunk_size,
        )
        t_crn = time.time() - t0

        self.rms = RunningRMS(RunningRMSConfig(
            enabled=self.cfg.rms_enabled, alpha=self.cfg.rms_alpha,
            ema_decay=self.cfg.rms_ema_decay, eps=self.cfg.rms_eps,
        ))

        h_d_fingerprint = self.h_D.sum().item()
        banks_fingerprint = sum(s.item() for s in self.bank.sigmas)
        print(
            f"[LCG] round={self.round_id} refresh: N={dataset.num_steps} "
            f"h_D_fingerprint={h_d_fingerprint:.6f} (t={t_h_d:.2f}s)  "
            f"banks_fingerprint={banks_fingerprint:.6f} (t={t_crn:.2f}s)",
            flush=True,
        )

        call_index = {"n": 0}

        def hook(infos, env_rew):
            t0_ = time.time()
            raw = base_hook(infos, env_rew)
            t_score = time.time() - t0_
            normalized = self.rms(raw)
            call_index["n"] += 1
            print(
                f"[LCG] round={self.round_id} ac_call={call_index['n']} "
                f"h_D_fingerprint={self.h_D.sum().item():.6f} banks_fingerprint="
                f"{sum(s.item() for s in self.bank.sigmas):.6f} "
                f"rms_s2={self.rms.s2.item():.6f} raw_reward_mean={raw.mean().item():.4f} "
                f"raw_reward_min={raw.min().item():.4f} norm_reward_mean={normalized.mean().item():.4f} "
                f"norm_reward_min={normalized.min().item():.4f} scoring_time={t_score:.3f}s",
                flush=True,
            )
            return normalized

        self.intrinsic_reward_fn = hook
